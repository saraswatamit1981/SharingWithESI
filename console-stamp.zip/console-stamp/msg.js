const chalk = require('chalk');
console.log('Attention')
console.log(chalk.yellow('    Console-stamp version 3.0.0 Release Candidate is out. Install by using the tag \'@next\'. NB: Breaking changes.'));
console.log('    For more details goto: https://www.npmjs.com/package/console-stamp/v/next\n');
