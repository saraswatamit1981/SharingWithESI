function getPlainTextTemplate(options) {
    var message = {
        "type": "template",
        "metaTags": options.metaTags || [],
        "payload": {
            "template_type": "text",
            "text": options.text
        }
    }
    BotUserSession.put("message", message);
    return JSON.stringify(message);
}

function getQuickRepliesTemplate(options) {
    var message = {
        "type": "template",
        "metaTags": options.metaTags || [],
        "payload": {
            "template_type": "quick_replies",
            "text": options.text,
            "quick_replies": []
        }
    };
    for (i = 0; i < options.items.length; i++) {
        var quickReply = {
            "content_type": "text",
            "title": options.items[i].title || options.items[i],
            "payload": options.items[i].value || options.items[i]
        };
        message.payload.quick_replies.push(quickReply);
    }
    BotUserSession.put("message", message);
    return JSON.stringify(message);
}

function getTableTemplate(options) {
  //  koreDebugger.log("options " + JSON.stringify(options));
    var message = {
        "type": "template",
        "metaTags": options.metaTags || [],
        "payload": {
            "template_type": "table",
            "text": options.text,
            "columns": options.columns,
            "columnHeaders": options.columns,
            "table_design": "regular",
            "type": "regular",
            "primary": options.columns[0][0],
            speech_hint: "Here is your account details",
            elements: []
        }
    };
    var ele = [];
    var ele_rows = []
    for (var i = 0; i < options.items.length; i++) {
        let elementArr = Object.keys(options.items[i]).map(key => {
          //  koreDebugger.log("key " + JSON.stringify(key));
            return options.items[i][key]
        });
        //koreDebugger.log("elementArr " + JSON.stringify(elementArr));
        ele.push({
            'Values': elementArr
        });
        ele_rows.push(elementArr);
    }
    message.payload.elements = ele;
    message.payload.rowData = ele_rows;
    return JSON.stringify(message);
}

function getLinkTemplate(options) {
  //  koreDebugger.log("options " + JSON.stringify(options));
    let message = {
        "type": "template",
        "metaTags": options.metaTags || [],
        "payload": {
            "template_type": "link",
            "text": options.text,
            "linkText": {
                "link_1": {
                    "type": "url",
                    "label": options.linkTextName,
                    "url": options.link,
                    "target": options.target
                }
            }
        }
    }
    if (options.link_1) {
        message.payload.linkText["link_2"] = {};
        message.payload.linkText["link_2"] = options.link_1;
    }
   // koreDebugger.log("message " + JSON.stringify(message));
    return JSON.stringify(message);
}

function getButtonTemplate(options) {
    var message = {
        "type": "template",
        "metaTags": options.metaTags || [],
        "payload": {
            "template_type": "button",
            "text": options.text,
            "buttons": []
        }
    };
    for (i = 0; i < options.items.length; i++) {
        var button = {
            "type": "postback"
        };
        button.title = options.items[i].title || options.items[i];
        button.payload = options.items[i].value || options.items[i];
        message.payload.buttons.push(button);
    }
    BotUserSession.put("message", message);
    return JSON.stringify(message);
}

function getOrderedListTemalate(options) {
    var message = {
        "type": "template",
        "metaTags": options.metaTags || [],
        "payload": {
            "template_type": "ordered_list",
            "text": options.text,
            "list_items": options.items
        }
    };
    return JSON.stringify(message);
}

function getUnorderedListTemalate(options) {
    var message = {
        "type": "template",
        "metaTags": options.metaTags || [],
        "payload": {
            "template_type": "unordered_list",
            "text": options.text,
            "list_items": options.items
        }
    };
    return JSON.stringify(message)
}


function getCustomDataObject(context) {
    let botUserSession = context.session.BotUserSession;
    let customData;
    if ((botUserSession.lastMessage && botUserSession.lastMessage.channel == "rtm") || (botUserSession.channels && Array.isArray(botUserSession.channels) && botUserSession.channels[0] && botUserSession.channels[0].type == "rtm")) {
        customData = botUserSession.channels && Array.isArray(botUserSession.channels) && botUserSession.channels[0] && botUserSession.channels[0].botInfo && botUserSession.channels[0].botInfo.customData;
    } else if (botUserSession.lastMessage && botUserSession.lastMessage.channel == "ivr") {
        customData = botUserSession.lastMessage.messagePayload && botUserSession.lastMessage.messagePayload.customData;
    }
    return customData;
}

function getLatestToken(context) {
    let botUserSession = context.session.BotUserSession;
    let customData = getCustomDataObject(context);
    let token;
    if (customData && customData.token && customData.token !== undefined) {
        token = customData.token;
        if (token.indexOf("Bearer ") < 0) {
            token = "Bearer " + token;
        }
    }
    if (token !== undefined) BotUserSession.put("Token", token);
}

function getErrorPrompt(context) {
    let message = context.session.BotUserSession.message;
    message.payload.text = content.entityErrorPrompt;
    return JSON.stringify(message);
}

function getEntitlementCheck(RemitCheck, entitlements) {
    let flag = RemitCheck.includes(entitlements) ? true : false;
    return flag;
}

function getQuickRepliesWithLinkText(options) {
	//koreDebugger.log(JSON.stringify(options))
    var message = {
        "type": "template",
        "metaTags": options.metaTags || [],
        "payload": {
            "template_type": "cta_link_list",
            "text": options.text,
            "linkText": {
                "link_1": {
                    "type": "url",
                    "label": options.linkTextName,
                    "url": options.link,
                    "target": options.target
                }
            },
            "quick_replies": []
        }
    }

    if (options.link_1) {
        message.payload.linkText["link_2"] = {};
        message.payload.linkText["link_2"] = options.link_1;
    }
    for (i = 0; i < options.items.length; i++) {
        var quickReply = {
            "content_type": "text",
            "title": options.items[i].title || options.items[i],
            "payload": options.items[i].value || options.items[i]
        };
        message.payload.quick_replies.push(quickReply);
    }
	//koreDebugger.log("getQuickRepliesWithLinkText ==>" + JSON.stringify(message));
    return JSON.stringify(message);
}